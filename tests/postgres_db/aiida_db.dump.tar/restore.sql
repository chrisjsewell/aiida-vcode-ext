--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aiida_db;
--
-- Name: aiida_db; Type: DATABASE; Schema: -; Owner: aiida
--

CREATE DATABASE aiida_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE aiida_db OWNER TO aiida;

\connect aiida_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO aiida;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO aiida;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO aiida;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO aiida;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO aiida;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO aiida;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: db_dbauthinfo; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbauthinfo (
    id integer NOT NULL,
    auth_params jsonb NOT NULL,
    metadata jsonb NOT NULL,
    enabled boolean NOT NULL,
    aiidauser_id integer NOT NULL,
    dbcomputer_id integer NOT NULL
);


ALTER TABLE public.db_dbauthinfo OWNER TO aiida;

--
-- Name: db_dbauthinfo_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbauthinfo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbauthinfo_id_seq OWNER TO aiida;

--
-- Name: db_dbauthinfo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbauthinfo_id_seq OWNED BY public.db_dbauthinfo.id;


--
-- Name: db_dbcomment; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbcomment (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    ctime timestamp with time zone NOT NULL,
    mtime timestamp with time zone NOT NULL,
    content text NOT NULL,
    dbnode_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.db_dbcomment OWNER TO aiida;

--
-- Name: db_dbcomment_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbcomment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbcomment_id_seq OWNER TO aiida;

--
-- Name: db_dbcomment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbcomment_id_seq OWNED BY public.db_dbcomment.id;


--
-- Name: db_dbcomputer; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbcomputer (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    name character varying(255) NOT NULL,
    hostname character varying(255) NOT NULL,
    description text NOT NULL,
    transport_type character varying(255) NOT NULL,
    scheduler_type character varying(255) NOT NULL,
    metadata jsonb NOT NULL
);


ALTER TABLE public.db_dbcomputer OWNER TO aiida;

--
-- Name: db_dbcomputer_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbcomputer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbcomputer_id_seq OWNER TO aiida;

--
-- Name: db_dbcomputer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbcomputer_id_seq OWNED BY public.db_dbcomputer.id;


--
-- Name: db_dbgroup; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbgroup (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    label character varying(255) NOT NULL,
    type_string character varying(255) NOT NULL,
    "time" timestamp with time zone NOT NULL,
    description text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.db_dbgroup OWNER TO aiida;

--
-- Name: db_dbgroup_dbnodes; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbgroup_dbnodes (
    id integer NOT NULL,
    dbgroup_id integer NOT NULL,
    dbnode_id integer NOT NULL
);


ALTER TABLE public.db_dbgroup_dbnodes OWNER TO aiida;

--
-- Name: db_dbgroup_dbnodes_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbgroup_dbnodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbgroup_dbnodes_id_seq OWNER TO aiida;

--
-- Name: db_dbgroup_dbnodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbgroup_dbnodes_id_seq OWNED BY public.db_dbgroup_dbnodes.id;


--
-- Name: db_dbgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbgroup_id_seq OWNER TO aiida;

--
-- Name: db_dbgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbgroup_id_seq OWNED BY public.db_dbgroup.id;


--
-- Name: db_dblink; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dblink (
    id integer NOT NULL,
    label character varying(255) NOT NULL,
    input_id integer NOT NULL,
    output_id integer NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE public.db_dblink OWNER TO aiida;

--
-- Name: db_dblink_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dblink_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dblink_id_seq OWNER TO aiida;

--
-- Name: db_dblink_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dblink_id_seq OWNED BY public.db_dblink.id;


--
-- Name: db_dblog; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dblog (
    id integer NOT NULL,
    "time" timestamp with time zone NOT NULL,
    loggername character varying(255) NOT NULL,
    levelname character varying(50) NOT NULL,
    message text NOT NULL,
    metadata jsonb NOT NULL,
    dbnode_id integer NOT NULL,
    uuid uuid NOT NULL
);


ALTER TABLE public.db_dblog OWNER TO aiida;

--
-- Name: db_dblog_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dblog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dblog_id_seq OWNER TO aiida;

--
-- Name: db_dblog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dblog_id_seq OWNED BY public.db_dblog.id;


--
-- Name: db_dbnode; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbnode (
    id integer NOT NULL,
    uuid uuid NOT NULL,
    node_type character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    description text NOT NULL,
    ctime timestamp with time zone NOT NULL,
    mtime timestamp with time zone NOT NULL,
    dbcomputer_id integer,
    user_id integer NOT NULL,
    process_type character varying(255),
    attributes jsonb,
    extras jsonb
);


ALTER TABLE public.db_dbnode OWNER TO aiida;

--
-- Name: db_dbnode_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbnode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbnode_id_seq OWNER TO aiida;

--
-- Name: db_dbnode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbnode_id_seq OWNED BY public.db_dbnode.id;


--
-- Name: db_dbsetting; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbsetting (
    id integer NOT NULL,
    key character varying(1024) NOT NULL,
    description text NOT NULL,
    "time" timestamp with time zone NOT NULL,
    val jsonb
);


ALTER TABLE public.db_dbsetting OWNER TO aiida;

--
-- Name: db_dbsetting_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbsetting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbsetting_id_seq OWNER TO aiida;

--
-- Name: db_dbsetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbsetting_id_seq OWNED BY public.db_dbsetting.id;


--
-- Name: db_dbuser; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.db_dbuser (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    first_name character varying(254) NOT NULL,
    last_name character varying(254) NOT NULL,
    institution character varying(254) NOT NULL
);


ALTER TABLE public.db_dbuser OWNER TO aiida;

--
-- Name: db_dbuser_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.db_dbuser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.db_dbuser_id_seq OWNER TO aiida;

--
-- Name: db_dbuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.db_dbuser_id_seq OWNED BY public.db_dbuser.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO aiida;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO aiida;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: aiida
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO aiida;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: aiida
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO aiida;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aiida
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: db_dbauthinfo id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbauthinfo ALTER COLUMN id SET DEFAULT nextval('public.db_dbauthinfo_id_seq'::regclass);


--
-- Name: db_dbcomment id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomment ALTER COLUMN id SET DEFAULT nextval('public.db_dbcomment_id_seq'::regclass);


--
-- Name: db_dbcomputer id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomputer ALTER COLUMN id SET DEFAULT nextval('public.db_dbcomputer_id_seq'::regclass);


--
-- Name: db_dbgroup id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup ALTER COLUMN id SET DEFAULT nextval('public.db_dbgroup_id_seq'::regclass);


--
-- Name: db_dbgroup_dbnodes id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup_dbnodes ALTER COLUMN id SET DEFAULT nextval('public.db_dbgroup_dbnodes_id_seq'::regclass);


--
-- Name: db_dblink id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblink ALTER COLUMN id SET DEFAULT nextval('public.db_dblink_id_seq'::regclass);


--
-- Name: db_dblog id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblog ALTER COLUMN id SET DEFAULT nextval('public.db_dblog_id_seq'::regclass);


--
-- Name: db_dbnode id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbnode ALTER COLUMN id SET DEFAULT nextval('public.db_dbnode_id_seq'::regclass);


--
-- Name: db_dbsetting id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbsetting ALTER COLUMN id SET DEFAULT nextval('public.db_dbsetting_id_seq'::regclass);


--
-- Name: db_dbuser id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbuser ALTER COLUMN id SET DEFAULT nextval('public.db_dbuser_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3133.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3135.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3131.dat';

--
-- Data for Name: db_dbauthinfo; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbauthinfo (id, auth_params, metadata, enabled, aiidauser_id, dbcomputer_id) FROM stdin;
\.
COPY public.db_dbauthinfo (id, auth_params, metadata, enabled, aiidauser_id, dbcomputer_id) FROM '$$PATH$$/3139.dat';

--
-- Data for Name: db_dbcomment; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbcomment (id, uuid, ctime, mtime, content, dbnode_id, user_id) FROM stdin;
\.
COPY public.db_dbcomment (id, uuid, ctime, mtime, content, dbnode_id, user_id) FROM '$$PATH$$/3141.dat';

--
-- Data for Name: db_dbcomputer; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbcomputer (id, uuid, name, hostname, description, transport_type, scheduler_type, metadata) FROM stdin;
\.
COPY public.db_dbcomputer (id, uuid, name, hostname, description, transport_type, scheduler_type, metadata) FROM '$$PATH$$/3143.dat';

--
-- Data for Name: db_dbgroup; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbgroup (id, uuid, label, type_string, "time", description, user_id) FROM stdin;
\.
COPY public.db_dbgroup (id, uuid, label, type_string, "time", description, user_id) FROM '$$PATH$$/3145.dat';

--
-- Data for Name: db_dbgroup_dbnodes; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbgroup_dbnodes (id, dbgroup_id, dbnode_id) FROM stdin;
\.
COPY public.db_dbgroup_dbnodes (id, dbgroup_id, dbnode_id) FROM '$$PATH$$/3155.dat';

--
-- Data for Name: db_dblink; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dblink (id, label, input_id, output_id, type) FROM stdin;
\.
COPY public.db_dblink (id, label, input_id, output_id, type) FROM '$$PATH$$/3147.dat';

--
-- Data for Name: db_dblog; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dblog (id, "time", loggername, levelname, message, metadata, dbnode_id, uuid) FROM stdin;
\.
COPY public.db_dblog (id, "time", loggername, levelname, message, metadata, dbnode_id, uuid) FROM '$$PATH$$/3149.dat';

--
-- Data for Name: db_dbnode; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbnode (id, uuid, node_type, label, description, ctime, mtime, dbcomputer_id, user_id, process_type, attributes, extras) FROM stdin;
\.
COPY public.db_dbnode (id, uuid, node_type, label, description, ctime, mtime, dbcomputer_id, user_id, process_type, attributes, extras) FROM '$$PATH$$/3151.dat';

--
-- Data for Name: db_dbsetting; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbsetting (id, key, description, "time", val) FROM stdin;
\.
COPY public.db_dbsetting (id, key, description, "time", val) FROM '$$PATH$$/3153.dat';

--
-- Data for Name: db_dbuser; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.db_dbuser (id, email, first_name, last_name, institution) FROM stdin;
\.
COPY public.db_dbuser (id, email, first_name, last_name, institution) FROM '$$PATH$$/3137.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3129.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: aiida
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3127.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 48, true);


--
-- Name: db_dbauthinfo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbauthinfo_id_seq', 1, true);


--
-- Name: db_dbcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbcomment_id_seq', 1, false);


--
-- Name: db_dbcomputer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbcomputer_id_seq', 1, true);


--
-- Name: db_dbgroup_dbnodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbgroup_dbnodes_id_seq', 94, true);


--
-- Name: db_dbgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbgroup_id_seq', 4, true);


--
-- Name: db_dblink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dblink_id_seq', 43, true);


--
-- Name: db_dblog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dblog_id_seq', 9, true);


--
-- Name: db_dbnode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbnode_id_seq', 114, true);


--
-- Name: db_dbsetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbsetting_id_seq', 3, true);


--
-- Name: db_dbuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.db_dbuser_id_seq', 2, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 12, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aiida
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 57, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: db_dbauthinfo db_dbauthinfo_aiidauser_id_dbcomputer_id_777cdaa8_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbauthinfo
    ADD CONSTRAINT db_dbauthinfo_aiidauser_id_dbcomputer_id_777cdaa8_uniq UNIQUE (aiidauser_id, dbcomputer_id);


--
-- Name: db_dbauthinfo db_dbauthinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbauthinfo
    ADD CONSTRAINT db_dbauthinfo_pkey PRIMARY KEY (id);


--
-- Name: db_dbcomment db_dbcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomment
    ADD CONSTRAINT db_dbcomment_pkey PRIMARY KEY (id);


--
-- Name: db_dbcomment db_dbcomment_uuid_49bac08c_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomment
    ADD CONSTRAINT db_dbcomment_uuid_49bac08c_uniq UNIQUE (uuid);


--
-- Name: db_dbcomputer db_dbcomputer_name_key; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomputer
    ADD CONSTRAINT db_dbcomputer_name_key UNIQUE (name);


--
-- Name: db_dbcomputer db_dbcomputer_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomputer
    ADD CONSTRAINT db_dbcomputer_pkey PRIMARY KEY (id);


--
-- Name: db_dbcomputer db_dbcomputer_uuid_f35defa6_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomputer
    ADD CONSTRAINT db_dbcomputer_uuid_f35defa6_uniq UNIQUE (uuid);


--
-- Name: db_dbgroup_dbnodes db_dbgroup_dbnodes_dbgroup_id_dbnode_id_eee23cce_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup_dbnodes
    ADD CONSTRAINT db_dbgroup_dbnodes_dbgroup_id_dbnode_id_eee23cce_uniq UNIQUE (dbgroup_id, dbnode_id);


--
-- Name: db_dbgroup_dbnodes db_dbgroup_dbnodes_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup_dbnodes
    ADD CONSTRAINT db_dbgroup_dbnodes_pkey PRIMARY KEY (id);


--
-- Name: db_dbgroup db_dbgroup_name_type_12656f33_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup
    ADD CONSTRAINT db_dbgroup_name_type_12656f33_uniq UNIQUE (label, type_string);


--
-- Name: db_dbgroup db_dbgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup
    ADD CONSTRAINT db_dbgroup_pkey PRIMARY KEY (id);


--
-- Name: db_dbgroup db_dbgroup_uuid_af896177_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup
    ADD CONSTRAINT db_dbgroup_uuid_af896177_uniq UNIQUE (uuid);


--
-- Name: db_dblink db_dblink_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblink
    ADD CONSTRAINT db_dblink_pkey PRIMARY KEY (id);


--
-- Name: db_dblog db_dblog_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblog
    ADD CONSTRAINT db_dblog_pkey PRIMARY KEY (id);


--
-- Name: db_dblog db_dblog_uuid_9cf77df3_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblog
    ADD CONSTRAINT db_dblog_uuid_9cf77df3_uniq UNIQUE (uuid);


--
-- Name: db_dbnode db_dbnode_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbnode
    ADD CONSTRAINT db_dbnode_pkey PRIMARY KEY (id);


--
-- Name: db_dbnode db_dbnode_uuid_62e0bf98_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbnode
    ADD CONSTRAINT db_dbnode_uuid_62e0bf98_uniq UNIQUE (uuid);


--
-- Name: db_dbsetting db_dbsetting_key_1b84beb4_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbsetting
    ADD CONSTRAINT db_dbsetting_key_1b84beb4_uniq UNIQUE (key);


--
-- Name: db_dbsetting db_dbsetting_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbsetting
    ADD CONSTRAINT db_dbsetting_pkey PRIMARY KEY (id);


--
-- Name: db_dbuser db_dbuser_email_30150b7e_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbuser
    ADD CONSTRAINT db_dbuser_email_30150b7e_uniq UNIQUE (email);


--
-- Name: db_dbuser db_dbuser_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbuser
    ADD CONSTRAINT db_dbuser_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: db_dbauthinfo_aiidauser_id_0684fdfb; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbauthinfo_aiidauser_id_0684fdfb ON public.db_dbauthinfo USING btree (aiidauser_id);


--
-- Name: db_dbauthinfo_dbcomputer_id_424f7ac4; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbauthinfo_dbcomputer_id_424f7ac4 ON public.db_dbauthinfo USING btree (dbcomputer_id);


--
-- Name: db_dbcomment_dbnode_id_3b812b6b; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbcomment_dbnode_id_3b812b6b ON public.db_dbcomment USING btree (dbnode_id);


--
-- Name: db_dbcomment_user_id_8ed5e360; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbcomment_user_id_8ed5e360 ON public.db_dbcomment USING btree (user_id);


--
-- Name: db_dbcomputer_name_f1800b1a_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbcomputer_name_f1800b1a_like ON public.db_dbcomputer USING btree (name varchar_pattern_ops);


--
-- Name: db_dbgroup_dbnodes_dbgroup_id_9d3a0f9d; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_dbnodes_dbgroup_id_9d3a0f9d ON public.db_dbgroup_dbnodes USING btree (dbgroup_id);


--
-- Name: db_dbgroup_dbnodes_dbnode_id_118b9439; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_dbnodes_dbnode_id_118b9439 ON public.db_dbgroup_dbnodes USING btree (dbnode_id);


--
-- Name: db_dbgroup_name_66c75272; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_name_66c75272 ON public.db_dbgroup USING btree (label);


--
-- Name: db_dbgroup_name_66c75272_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_name_66c75272_like ON public.db_dbgroup USING btree (label varchar_pattern_ops);


--
-- Name: db_dbgroup_type_23b2a748; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_type_23b2a748 ON public.db_dbgroup USING btree (type_string);


--
-- Name: db_dbgroup_type_23b2a748_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_type_23b2a748_like ON public.db_dbgroup USING btree (type_string varchar_pattern_ops);


--
-- Name: db_dbgroup_user_id_100f8a51; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbgroup_user_id_100f8a51 ON public.db_dbgroup USING btree (user_id);


--
-- Name: db_dblink_input_id_9245bd73; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_input_id_9245bd73 ON public.db_dblink USING btree (input_id);


--
-- Name: db_dblink_label_f1343cfb; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_label_f1343cfb ON public.db_dblink USING btree (label);


--
-- Name: db_dblink_label_f1343cfb_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_label_f1343cfb_like ON public.db_dblink USING btree (label varchar_pattern_ops);


--
-- Name: db_dblink_output_id_c0167528; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_output_id_c0167528 ON public.db_dblink USING btree (output_id);


--
-- Name: db_dblink_type_229f212b; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_type_229f212b ON public.db_dblink USING btree (type);


--
-- Name: db_dblink_type_229f212b_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblink_type_229f212b_like ON public.db_dblink USING btree (type varchar_pattern_ops);


--
-- Name: db_dblog_dbnode_id_da34b732; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblog_dbnode_id_da34b732 ON public.db_dblog USING btree (dbnode_id);


--
-- Name: db_dblog_levelname_ad5dc346; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblog_levelname_ad5dc346 ON public.db_dblog USING btree (levelname);


--
-- Name: db_dblog_levelname_ad5dc346_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblog_levelname_ad5dc346_like ON public.db_dblog USING btree (levelname varchar_pattern_ops);


--
-- Name: db_dblog_loggername_00b5ba16; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblog_loggername_00b5ba16 ON public.db_dblog USING btree (loggername);


--
-- Name: db_dblog_loggername_00b5ba16_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dblog_loggername_00b5ba16_like ON public.db_dblog USING btree (loggername varchar_pattern_ops);


--
-- Name: db_dbnode_ctime_71626ef5; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_ctime_71626ef5 ON public.db_dbnode USING btree (ctime);


--
-- Name: db_dbnode_dbcomputer_id_315372a3; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_dbcomputer_id_315372a3 ON public.db_dbnode USING btree (dbcomputer_id);


--
-- Name: db_dbnode_label_6469539e; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_label_6469539e ON public.db_dbnode USING btree (label);


--
-- Name: db_dbnode_label_6469539e_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_label_6469539e_like ON public.db_dbnode USING btree (label varchar_pattern_ops);


--
-- Name: db_dbnode_mtime_0554ea3d; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_mtime_0554ea3d ON public.db_dbnode USING btree (mtime);


--
-- Name: db_dbnode_process_type_df7298d0; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_process_type_df7298d0 ON public.db_dbnode USING btree (process_type);


--
-- Name: db_dbnode_process_type_df7298d0_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_process_type_df7298d0_like ON public.db_dbnode USING btree (process_type varchar_pattern_ops);


--
-- Name: db_dbnode_type_a8ce9753; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_type_a8ce9753 ON public.db_dbnode USING btree (node_type);


--
-- Name: db_dbnode_type_a8ce9753_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_type_a8ce9753_like ON public.db_dbnode USING btree (node_type varchar_pattern_ops);


--
-- Name: db_dbnode_user_id_12e7aeaf; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbnode_user_id_12e7aeaf ON public.db_dbnode USING btree (user_id);


--
-- Name: db_dbsetting_key_1b84beb4_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbsetting_key_1b84beb4_like ON public.db_dbsetting USING btree (key varchar_pattern_ops);


--
-- Name: db_dbuser_email_30150b7e_like; Type: INDEX; Schema: public; Owner: aiida
--

CREATE INDEX db_dbuser_email_30150b7e_like ON public.db_dbuser USING btree (email varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbauthinfo db_dbauthinfo_aiidauser_id_0684fdfb_fk_db_dbuser_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbauthinfo
    ADD CONSTRAINT db_dbauthinfo_aiidauser_id_0684fdfb_fk_db_dbuser_id FOREIGN KEY (aiidauser_id) REFERENCES public.db_dbuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbauthinfo db_dbauthinfo_dbcomputer_id_424f7ac4_fk_db_dbcomputer_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbauthinfo
    ADD CONSTRAINT db_dbauthinfo_dbcomputer_id_424f7ac4_fk_db_dbcomputer_id FOREIGN KEY (dbcomputer_id) REFERENCES public.db_dbcomputer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbcomment db_dbcomment_dbnode_id_3b812b6b_fk_db_dbnode_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomment
    ADD CONSTRAINT db_dbcomment_dbnode_id_3b812b6b_fk_db_dbnode_id FOREIGN KEY (dbnode_id) REFERENCES public.db_dbnode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbcomment db_dbcomment_user_id_8ed5e360_fk_db_dbuser_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbcomment
    ADD CONSTRAINT db_dbcomment_user_id_8ed5e360_fk_db_dbuser_id FOREIGN KEY (user_id) REFERENCES public.db_dbuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbgroup_dbnodes db_dbgroup_dbnodes_dbgroup_id_9d3a0f9d_fk_db_dbgroup_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup_dbnodes
    ADD CONSTRAINT db_dbgroup_dbnodes_dbgroup_id_9d3a0f9d_fk_db_dbgroup_id FOREIGN KEY (dbgroup_id) REFERENCES public.db_dbgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbgroup_dbnodes db_dbgroup_dbnodes_dbnode_id_118b9439_fk_db_dbnode_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup_dbnodes
    ADD CONSTRAINT db_dbgroup_dbnodes_dbnode_id_118b9439_fk_db_dbnode_id FOREIGN KEY (dbnode_id) REFERENCES public.db_dbnode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbgroup db_dbgroup_user_id_100f8a51_fk_db_dbuser_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbgroup
    ADD CONSTRAINT db_dbgroup_user_id_100f8a51_fk_db_dbuser_id FOREIGN KEY (user_id) REFERENCES public.db_dbuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dblink db_dblink_input_id_9245bd73_fk_db_dbnode_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblink
    ADD CONSTRAINT db_dblink_input_id_9245bd73_fk_db_dbnode_id FOREIGN KEY (input_id) REFERENCES public.db_dbnode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dblink db_dblink_output_id_c0167528_fk_db_dbnode_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblink
    ADD CONSTRAINT db_dblink_output_id_c0167528_fk_db_dbnode_id FOREIGN KEY (output_id) REFERENCES public.db_dbnode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dblog db_dblog_dbnode_id_da34b732_fk_db_dbnode_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dblog
    ADD CONSTRAINT db_dblog_dbnode_id_da34b732_fk_db_dbnode_id FOREIGN KEY (dbnode_id) REFERENCES public.db_dbnode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbnode db_dbnode_dbcomputer_id_315372a3_fk_db_dbcomputer_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbnode
    ADD CONSTRAINT db_dbnode_dbcomputer_id_315372a3_fk_db_dbcomputer_id FOREIGN KEY (dbcomputer_id) REFERENCES public.db_dbcomputer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: db_dbnode db_dbnode_user_id_12e7aeaf_fk_db_dbuser_id; Type: FK CONSTRAINT; Schema: public; Owner: aiida
--

ALTER TABLE ONLY public.db_dbnode
    ADD CONSTRAINT db_dbnode_user_id_12e7aeaf_fk_db_dbuser_id FOREIGN KEY (user_id) REFERENCES public.db_dbuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

